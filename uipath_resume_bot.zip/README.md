UiPath Resume + Job Reminder Bot

Scaffold project.